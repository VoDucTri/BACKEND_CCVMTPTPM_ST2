﻿using System.ComponentModel.DataAnnotations;

namespace nhom5_webAPI.Models
{
    public class ServiceImage
    {
        [Key]
        public int Id { get; set; }
        public int ServiceId { get; set; }
        public Service Service { get; set; }
        public string ImageUrl { get; set; } = string.Empty;
    }
}
