﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace nhom5_webAPI.Models
{
    public class OrderDetail
    {
        [Key]
        public int Id { get; set; } // Khóa chính

        [Required]
        public int OrderId { get; set; } // Khóa ngoại đến Order

        [ForeignKey("OrderId")]
        public Order Order { get; set; } = null!; // Navigation property đến Order

        [Required]
        [StringLength(50)]
        public string ProductType { get; set; } = string.Empty; // Loại sản phẩm (Pet hoặc Product)

        [Required]
        public int ProductId { get; set; } // Khóa ngoại đến Pet/Product (tùy thuộc vào ProductType)

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1.")]
        public int Quantity { get; set; } // Số lượng sản phẩm

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; } // Giá của sản phẩm
    }
}
