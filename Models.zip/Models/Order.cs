﻿using nhom5_webAPI.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

public class Order
{
    [Key]
    public int OrderId { get; set; } // Khóa chính

    [Required]
    public string UserId { get; set; } // Khóa ngoại đến bảng User

    [ForeignKey("UserId")]
    public User User { get; set; } = null!; // Navigation property

    [Required]
    public DateTime OrderDate { get; set; } // Ngày đặt hàng

    [Required]
    public decimal TotalPrice { get; set; } // Tổng giá trị đơn hàng

    [Required]
    public string Status { get; set; } = "Pending"; // Trạng thái đơn hàng

    // Navigation property đến OrderDetails
    public ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
}
